package com.example.tourmate.Interface;

import com.example.tourmate.PojoClass.Event;

import java.util.List;

public interface EventObjectListiner {
    void getEvent(List<Event> eventList);
}
