package com.example.tourmate.DatabaseUtils;

import com.example.tourmate.PojoClass.Event;

import java.util.List;

public class EventDataStaice {
    public static List<Event> eventList;
}
