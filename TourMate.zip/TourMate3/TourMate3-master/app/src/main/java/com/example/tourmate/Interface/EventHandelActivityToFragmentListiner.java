package com.example.tourmate.Interface;

public interface EventHandelActivityToFragmentListiner {
    void getActivityStatus(String status);
}
