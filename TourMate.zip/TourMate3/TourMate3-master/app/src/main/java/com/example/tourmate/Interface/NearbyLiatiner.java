package com.example.tourmate.Interface;

import com.example.tourmate.LocationAndMap.NearbySearch.NearbyPojo.Result;
import com.google.android.gms.maps.model.LatLng;

import java.util.List;

public interface NearbyLiatiner  {
    void getLatlon(LatLng latLng);
}

